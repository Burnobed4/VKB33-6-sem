from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegisterForm, ProfileEditForm
from .models import CustomUser


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # автоматический логин после регистрации
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


@login_required
def user_list(request):
    """Список всех пользователей — только для аутентифицированных."""
    my_friends = set(request.user.friends.values_list('pk', flat=True))
    users = CustomUser.objects.exclude(pk=request.user.pk)
    # Аннотируем флаг дружбы прямо здесь, чтобы не вызывать методы в шаблоне
    users_with_flag = [
        {'user': u, 'is_friend': u.pk in my_friends}
        for u in users
    ]
    return render(request, 'users/user_list.html', {'users_with_flag': users_with_flag})


@login_required
def profile(request, username):
    """Страница профиля пользователя."""
    profile_user = get_object_or_404(CustomUser, username=username)

    # Анонимы и незнакомые не могут смотреть чужие профили
    if not profile_user.can_view_profile(request.user):
        messages.error(request, 'Вы не можете просматривать эту страницу. Сначала добавьте пользователя в друзья.')
        return redirect('user_list')

    is_own = (request.user == profile_user)
    is_friend = request.user.is_friend(profile_user)

    # Для списка друзей профиля — проверяем, кого из них viewer может видеть
    my_friends = set(request.user.friends.values_list('pk', flat=True))
    friends_list = [
        {'user': f, 'can_view': (f.pk in my_friends or is_own)}
        for f in profile_user.friends.all()
    ]

    return render(request, 'users/profile.html', {
        'profile_user': profile_user,
        'is_own': is_own,
        'is_friend': is_friend,
        'friends_list': friends_list,
    })


@login_required
def profile_edit(request):
    """Редактирование своего профиля."""
    if request.method == 'POST':
        form = ProfileEditForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Профиль обновлён.')
            return redirect('profile', username=request.user.username)
    else:
        form = ProfileEditForm(instance=request.user)
    return render(request, 'users/profile_edit.html', {'form': form})


@login_required
def add_friend(request, username):
    """Добавить пользователя в друзья."""
    target = get_object_or_404(CustomUser, username=username)
    if target == request.user:
        messages.error(request, 'Нельзя добавить себя в друзья.')
    else:
        request.user.friends.add(target)
        messages.success(request, f'Пользователь {target.username} добавлен в друзья.')
    return redirect('user_list')


@login_required
def remove_friend(request, username):
    """Удалить пользователя из друзей."""
    target = get_object_or_404(CustomUser, username=username)
    request.user.friends.remove(target)
    messages.success(request, f'Пользователь {target.username} удалён из друзей.')
    return redirect('profile', username=username)
