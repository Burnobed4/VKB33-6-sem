COURSES = [
    {
        'id': 1,
        'title': 'Python для начинающих',
        'description': 'Основы программирования на Python',
        'duration': '40 часов',
        'price': 'Бесплатно',
        'author_id': 1,
    },
    {
        'id': 2,
        'title': 'Django - это просто',
        'description': 'Создание веб-приложений на Django',
        'duration': '60 часов',
        'price': '15 000 руб',
        'author_id': 1,
    },
    {
        'id': 3,
        'title': 'JavaScript продвинутый',
        'description': 'Продвинутые техники JavaScript',
        'duration': '50 часов',
        'price': '12 000 руб',
        'author_id': 2
    },
]

AUTHORS = [
    {
        'id': 1,
        'name': 'Иван Петров',
        'bio': 'Опытный разработчик с 10-летним стажем',
        'specialization': 'Python, Django',
    },
    {
        'id': 2,
        'name': 'Мария Сидорова',
        'bio': 'Frontend разработчик, эксперт по JavaScript',
        'specialization': 'JavaScript, React',
    },
]

# Информация о проекте
PROJECT_INFO = {
    'name': 'Каталог курсов',
    'version': '1.0.0',
    'description': 'Учебный проект для изучения Django',
    'technologies': ['Python', 'Django', 'HTML', 'CSS'],
}