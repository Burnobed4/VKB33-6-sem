from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from decimal import Decimal

class Teacher(models.Model):
    EXPERIENCE_LEVELS = [
        ('JUN', 'Junior'),
        ('MID', 'Middle'),
        ('SEN', 'Senior'),
        ('LEAD', 'Lead'),
    ]

    first_name = models.CharField(max_length=50, verbose_name='Имя')
    last_name = models.CharField(max_length=50, verbose_name='Фамилия')
    email = models.EmailField(unique=True, verbose_name='Email')
    phone = models.CharField(max_length=20, blank=True, null=True, verbose_name='Телефон')
    experience_level = models.CharField(max_length=4, choices=EXPERIENCE_LEVELS, default='JUN')
    hire_date = models.DateField(verbose_name='Дата найма')
    is_active = models.BooleanField(default=True, verbose_name='Активный')


    salary = models.DecimalField(
        max_digits=10, decimal_places=2,
        verbose_name='Зарплата',
        validators=[MinValueValidator(0)],
        default=0
    )
    years_of_experience = models.PositiveIntegerField(
        verbose_name='Лет опыта',
        default=0,
        validators=[MaxValueValidator(60)]
    )
    rating = models.DecimalField(
        max_digits=3, decimal_places=1,
        verbose_name='Рейтинг',
        default=5.0,
        validators=[MinValueValidator(0.0), MaxValueValidator(10.0)]
    )
    department = models.CharField(
        max_length=100,
        verbose_name='Отдел',
        blank=True,
        default=''
    )
    max_students = models.PositiveIntegerField(
        verbose_name='Макс. студентов',
        default=30,
        validators=[MinValueValidator(1), MaxValueValidator(500)]
    )

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    class Meta:
        verbose_name = 'Преподаватель'
        verbose_name_plural = 'Преподаватели'


class TeacherInfo(models.Model):
    """Дополнительная информация о преподавателе (связь 1:1)"""
    teacher = models.OneToOneField(
        Teacher,
        on_delete=models.CASCADE,
        related_name='info',
        verbose_name='Преподаватель'
    )
    bio = models.TextField(max_length=1000, verbose_name='Биография')
    education = models.CharField(max_length=200, verbose_name='Образование')
    specialization = models.CharField(max_length=200, verbose_name='Специализация')
    portfolio_url = models.URLField(blank=True, null=True, verbose_name='Портфолио')

    # Новые поля
    github_url = models.URLField(blank=True, null=True, verbose_name='GitHub')
    publications_count = models.PositiveIntegerField(
        verbose_name='Количество публикаций',
        default=0
    )
    languages = models.CharField(
        max_length=200,
        verbose_name='Языки',
        blank=True,
        default='Русский'
    )
    awards = models.TextField(
        max_length=500,
        verbose_name='Награды',
        blank=True,
        default=''
    )
    is_verified = models.BooleanField(default=False, verbose_name='Верифицирован')

    def __str__(self):
        return f"Информация о {self.teacher}"

    class Meta:
        verbose_name = 'Информация о преподавателе'
        verbose_name_plural = 'Информация о преподавателях'


class Course(models.Model):
    """Курс (связь N:1 с Teacher)"""
    LEVEL_CHOICES = [
        ('BEG', 'Начинающий'),
        ('INT', 'Средний'),
        ('ADV', 'Продвинутый'),
    ]

    title = models.CharField(max_length=100, verbose_name='Название')
    description = models.TextField(max_length=500, verbose_name='Описание')
    teacher = models.ForeignKey(
        Teacher,
        on_delete=models.SET_NULL,
        related_name='courses',
        null=True,
        blank=True,
        verbose_name='Преподаватель'
    )
    duration = models.IntegerField(
        verbose_name='Длительность (часов)',
        validators=[MinValueValidator(1)]
    )
    price = models.DecimalField(
        max_digits=10, decimal_places=2,
        verbose_name='Цена',
        validators=[MinValueValidator(0)]
    )
    start_date = models.DateField(verbose_name='Дата старта')

    # Новые поля
    end_date = models.DateField(verbose_name='Дата окончания', null=True, blank=True)
    level = models.CharField(
        max_length=3,
        choices=LEVEL_CHOICES,
        default='BEG',
        verbose_name='Уровень'
    )
    max_students = models.PositiveIntegerField(
        verbose_name='Макс. студентов',
        default=20,
        validators=[MinValueValidator(1)]
    )
    discount = models.PositiveIntegerField(
        verbose_name='Скидка (%)',
        default=0,
        validators=[MaxValueValidator(100)]
    )

    def discounted_price(self):
        if self.discount > 0:
            return round(self.price * (1 - Decimal(self.discount) / Decimal('100')), 2)
        return self.price

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Курс'
        verbose_name_plural = 'Курсы'
        unique_together = ['title', 'teacher']


class Student(models.Model):
    phone_validator = RegexValidator(
        regex=r'^\+?[\d\s\-\(\)]{7,20}$',
        message='Введите корректный номер телефона'
    )

    first_name = models.CharField(max_length=50, verbose_name='Имя')
    last_name = models.CharField(max_length=50, verbose_name='Фамилия')
    email = models.EmailField(unique=True, verbose_name='Email')
    phone = models.CharField(
        max_length=20, blank=True, null=True,
        verbose_name='Телефон',
        validators=[phone_validator]
    )
    birth_date = models.DateField(verbose_name='Дата рождения')
    enrollment_date = models.DateField(auto_now_add=True, verbose_name='Дата регистрации')

    # Новые поля
    city = models.CharField(max_length=100, verbose_name='Город', blank=True, default='')
    education_level = models.CharField(
        max_length=50,
        verbose_name='Уровень образования',
        blank=True,
        default=''
    )
    is_employed = models.BooleanField(default=False, verbose_name='Трудоустроен')
    gpa = models.DecimalField(
        max_digits=3, decimal_places=1,
        verbose_name='Средний балл',
        null=True, blank=True,
        validators=[MinValueValidator(0.0), MaxValueValidator(5.0)]
    )
    telegram = models.CharField(
        max_length=100,
        verbose_name='Telegram',
        blank=True,
        default=''
    )

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    class Meta:
        verbose_name = 'Студент'
        verbose_name_plural = 'Студенты'


class Enrollment(models.Model):
    """Запись студента на курс (связь N:N через промежуточную таблицу)"""
    STATUS_CHOICES = [
        ('ENROLLED', 'Записан'),
        ('COMPLETED', 'Завершил'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, verbose_name='Студент')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, verbose_name='Курс')
    enrollment_date = models.DateField(auto_now_add=True, verbose_name='Дата записи')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='ENROLLED')

    def __str__(self):
        return f"{self.student} — {self.course}"

    class Meta:
        unique_together = ['student', 'course']
        verbose_name = 'Запись на курс'
        verbose_name_plural = 'Записи на курсы'
