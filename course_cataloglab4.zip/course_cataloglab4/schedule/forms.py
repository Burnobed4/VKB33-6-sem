import re
from datetime import date
from django import forms
from django.core.exceptions import ValidationError
from .models import Teacher, Course


def validate_phone_format(value):
    """Валидатор 1: телефон должен содержать только цифры, +, -, пробелы и скобки."""
    if value and not re.match(r'^\+?[\d\s\-\(\)]{7,20}$', value):
        raise ValidationError(
            'Неверный формат телефона. Используйте цифры, +, -, пробелы и скобки.'
        )


def validate_no_digits_in_name(value):
    """Валидатор 2: имя/фамилия не должны содержать цифры."""
    if any(char.isdigit() for char in value):
        raise ValidationError('Имя и фамилия не должны содержать цифры.')


def validate_hire_date_not_future(value):
    """Валидатор 3: дата найма не может быть в будущем."""
    if value and value > date.today():
        raise ValidationError('Дата найма не может быть в будущем.')


def validate_price_not_zero(value):
    """Валидатор 4: цена не должна быть отрицательной."""
    if value is not None and value < 0:
        raise ValidationError('Цена не может быть отрицательной.')


def validate_duration_reasonable(value):
    """Валидатор 5: длительность курса не должна превышать 2000 часов."""
    if value and value > 2000:
        raise ValidationError('Длительность курса не может превышать 2000 часов.')


class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = [
            'first_name', 'last_name', 'email', 'phone',
            'experience_level', 'hire_date', 'is_active',
            'salary', 'years_of_experience', 'rating', 'department', 'max_students',
        ]
        widgets = {
            'first_name': forms.TextInput(attrs={'placeholder': 'Например: Иван'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Например: Петров'}),
            'email': forms.EmailInput(attrs={'placeholder': 'ivan@example.com'}),
            'phone': forms.TextInput(attrs={'placeholder': '+7 (999) 123-45-67'}),
            'hire_date': forms.DateInput(attrs={'placeholder': 'ГГГГ-ММ-ДД', 'type': 'date'}),
            'salary': forms.NumberInput(attrs={'placeholder': '50000'}),
            'years_of_experience': forms.NumberInput(attrs={'placeholder': '5'}),
            'rating': forms.NumberInput(attrs={'placeholder': '8.5', 'step': '0.1'}),
            'department': forms.TextInput(attrs={'placeholder': 'Кафедра информатики'}),
            'max_students': forms.NumberInput(attrs={'placeholder': '30'}),
        }
        labels = {
            'first_name': 'Имя',
            'last_name': 'Фамилия',
            'email': 'Email',
            'phone': 'Телефон',
            'experience_level': 'Уровень',
            'hire_date': 'Дата найма',
            'is_active': 'Активный',
            'salary': 'Зарплата',
            'years_of_experience': 'Лет опыта',
            'rating': 'Рейтинг (0–10)',
            'department': 'Отдел',
            'max_students': 'Макс. студентов',
        }
        help_texts = {
            'first_name': 'Только буквы, без цифр',
            'last_name': 'Только буквы, без цифр',
            'phone': 'Необязательно. Формат: +7 (999) 123-45-67',
            'hire_date': 'Не может быть в будущем',
            'rating': 'От 0.0 до 10.0',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Добавляем кастомные валидаторы к полям
        self.fields['first_name'].validators.append(validate_no_digits_in_name)
        self.fields['last_name'].validators.append(validate_no_digits_in_name)
        self.fields['phone'].validators.append(validate_phone_format)
        self.fields['hire_date'].validators.append(validate_hire_date_not_future)


    def clean_first_name(self):
        """clean_1: имя начинается с заглавной буквы."""
        value = self.cleaned_data.get('first_name', '').strip()
        if value and not value[0].isupper():
            raise ValidationError('Имя должно начинаться с заглавной буквы.')
        return value.capitalize()

    def clean_last_name(self):
        """clean_2: фамилия начинается с заглавной буквы."""
        value = self.cleaned_data.get('last_name', '').strip()
        if value and not value[0].isupper():
            raise ValidationError('Фамилия должна начинаться с заглавной буквы.')
        return value.capitalize()

    def clean_email(self):
        """clean_3: email переводится в нижний регистр."""
        value = self.cleaned_data.get('email', '').strip().lower()
        return value

    def clean_rating(self):
        """clean_4: рейтинг кратен 0.5."""
        value = self.cleaned_data.get('rating')
        if value is not None:
            remainder = float(value) % 0.5
            if remainder != 0:
                raise ValidationError('Рейтинг должен быть кратен 0.5 (например: 7.0, 7.5, 8.0).')
        return value

    def clean(self):
        """clean(): проверка согласованности опыта и уровня."""
        cleaned_data = super().clean()
        experience_level = cleaned_data.get('experience_level')
        years = cleaned_data.get('years_of_experience')

        if experience_level and years is not None:
            requirements = {'JUN': (0, 2), 'MID': (2, 5), 'SEN': (5, 15), 'LEAD': (10, 60)}
            min_y, max_y = requirements.get(experience_level, (0, 60))
            if not (min_y <= years <= max_y):
                level_names = dict(Teacher.EXPERIENCE_LEVELS)
                raise ValidationError(
                    f'Для уровня «{level_names[experience_level]}» количество лет опыта '
                    f'должно быть от {min_y} до {max_y}. Указано: {years}.'
                )
        return cleaned_data



class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = [
            'title', 'description', 'teacher',
            'duration', 'price', 'start_date', 'end_date',
            'level', 'max_students', 'discount',
        ]
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'Например: Python для начинающих'}),
            'description': forms.Textarea(attrs={'placeholder': 'Краткое описание курса...', 'rows': 4}),
            'duration': forms.NumberInput(attrs={'placeholder': '40'}),
            'price': forms.NumberInput(attrs={'placeholder': '2499'}),
            'start_date': forms.DateInput(attrs={'placeholder': 'ГГГГ-ММ-ДД', 'type': 'date'}),
            'end_date': forms.DateInput(attrs={'placeholder': 'ГГГГ-ММ-ДД', 'type': 'date'}),
            'max_students': forms.NumberInput(attrs={'placeholder': '20'}),
            'discount': forms.NumberInput(attrs={'placeholder': '0'}),
        }
        labels = {
            'title': 'Название курса',
            'description': 'Описание',
            'teacher': 'Преподаватель',
            'duration': 'Длительность (часов)',
            'price': 'Цена (руб.)',
            'start_date': 'Дата старта',
            'end_date': 'Дата окончания',
            'level': 'Уровень',
            'max_students': 'Макс. студентов',
            'discount': 'Скидка (%)',
        }
        help_texts = {
            'price': 'Стоимость курса в рублях',
            'duration': 'Не более 2000 часов',
            'end_date': 'Необязательно. Должна быть позже даты старта',
            'discount': 'Процент скидки от 0 до 100',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['price'].validators.append(validate_price_not_zero)
        self.fields['duration'].validators.append(validate_duration_reasonable)

    def clean_title(self):
        """clean_1: название курса минимум 3 символа и начинается с буквы."""
        value = self.cleaned_data.get('title', '').strip()
        if len(value) < 3:
            raise ValidationError('Название курса должно содержать не менее 3 символов.')
        if value and not value[0].isalpha():
            raise ValidationError('Название курса должно начинаться с буквы.')
        return value

    def clean_description(self):
        """clean_2: описание минимум 10 символов."""
        value = self.cleaned_data.get('description', '').strip()
        if len(value) < 10:
            raise ValidationError('Описание должно содержать не менее 10 символов.')
        return value

    def clean_start_date(self):
        """clean_3: дата старта не может быть раньше 2000 года."""
        value = self.cleaned_data.get('start_date')
        if value and value.year < 2000:
            raise ValidationError('Дата старта не может быть раньше 2000 года.')
        return value

    def clean_discount(self):
        """clean_4: скидка 100% допускается только для бесплатных курсов."""
        discount = self.cleaned_data.get('discount')
        price = self.cleaned_data.get('price')
        if discount == 100 and price and price > 0:
            raise ValidationError(
                'Скидка 100% допускается только при цене 0. '
                'Установите цену 0 или уменьшите скидку.'
            )
        return discount

    def clean(self):
        """clean(): дата окончания позже даты старта + макс. студентов курса <= макс. студентов преподавателя."""
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')
        teacher = cleaned_data.get('teacher')
        max_students = cleaned_data.get('max_students')

        if start_date and end_date:
            if end_date <= start_date:
                raise ValidationError(
                    'Дата окончания должна быть позже даты старта курса.'
                )

        if teacher and max_students is not None:
            if max_students > teacher.max_students:
                raise ValidationError(
                    f'Максимальное количество студентов на курсе ({max_students}) '
                    f'не может превышать лимит преподавателя '
                    f'{teacher.first_name} {teacher.last_name} ({teacher.max_students}).'
                )

        return cleaned_data
