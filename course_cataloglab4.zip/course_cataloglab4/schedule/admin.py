from django.contrib import admin
from .models import Teacher, TeacherInfo, Course, Student, Enrollment

# Встроенная информация о преподавателе
class TeacherInfoInline(admin.StackedInline):
    model = TeacherInfo
    can_delete = False

# Админка для Teacher
@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'email', 'experience_level', 'is_active']
    list_filter = ['experience_level', 'is_active']
    search_fields = ['first_name', 'last_name', 'email']
    inlines = [TeacherInfoInline]

# Админка для TeacherInfo
@admin.register(TeacherInfo)
class TeacherInfoAdmin(admin.ModelAdmin):
    list_display = ['teacher', 'specialization', 'education']
    search_fields = ['teacher__first_name', 'teacher__last_name']

# Админка для Course
@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['title', 'teacher', 'start_date', 'price']
    list_filter = ['teacher']
    search_fields = ['title']

# Админка для Student
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'email']
    search_fields = ['first_name', 'last_name', 'email']

# Админка для Enrollment
@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ['student', 'course', 'status', 'enrollment_date']
    list_filter = ['status']