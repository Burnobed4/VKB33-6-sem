from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('catalog.urls')),
    path('schedule/', include('schedule.urls')),
]

handler404 = 'catalog.views.not_found'
