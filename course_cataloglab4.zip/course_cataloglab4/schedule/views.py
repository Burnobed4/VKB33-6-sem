from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Count
from .models import Teacher, TeacherInfo, Course, Student, Enrollment
from .forms import TeacherForm, CourseForm


def index(request):
    """Главная страница приложения schedule"""
    context = {
        'teachers_count': Teacher.objects.count(),
        'courses_count': Course.objects.count(),
        'students_count': Student.objects.count(),
        'title': 'Система расписания'
    }
    return render(request, 'schedule/index.html', context)


def teacher_list(request):
    """Список преподавателей"""
    context = {
        'teachers': Teacher.objects.all().prefetch_related('courses'),
        'title': 'Список преподавателей'
    }
    return render(request, 'schedule/teacher_list.html', context)


def teacher_detail(request, teacher_id):
    """Детальная страница преподавателя"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    context = {
        'teacher': teacher,
        'teacher_info': getattr(teacher, 'info', None),
        'courses': Course.objects.filter(teacher=teacher),
        'title': f'{teacher.first_name} {teacher.last_name}'
    }
    return render(request, 'schedule/teacher_detail.html', context)


def teacher_add(request):
    """Добавление преподавателя"""
    if request.method == 'POST':
        form = TeacherForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('teacher_list')
    else:
        form = TeacherForm()

    context = {'form': form, 'title': 'Добавить преподавателя'}
    return render(request, 'schedule/teacher_add.html', context)


def course_list(request):
    """Список курсов"""
    context = {
        'courses': Course.objects.all().select_related('teacher'),
        'title': 'Список курсов'
    }
    return render(request, 'schedule/course_list.html', context)


def course_detail(request, course_id):
    """Детальная страница курса"""
    course = get_object_or_404(Course, id=course_id)
    enrollments = Enrollment.objects.filter(course=course).select_related('student')
    context = {
        'course': course,
        'students': [e.student for e in enrollments],
        'enrollments': enrollments,
        'title': course.title
    }
    return render(request, 'schedule/course_detail.html', context)


def course_add(request):
    """Добавление курса"""
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm()

    context = {'form': form, 'title': 'Добавить курс'}
    return render(request, 'schedule/course_add.html', context)


def student_list(request):
    """Список студентов"""
    context = {
        'students': Student.objects.all(),
        'title': 'Список студентов'
    }
    return render(request, 'schedule/student_list.html', context)


def student_detail(request, student_id):
    """Детальная страница студента"""
    student = get_object_or_404(Student, id=student_id)
    enrollments = Enrollment.objects.filter(student=student).select_related('course')
    context = {
        'student': student,
        'courses': [e.course for e in enrollments],
        'enrollments': enrollments,
        'title': f'{student.first_name} {student.last_name}'
    }
    return render(request, 'schedule/student_detail.html', context)


def orm_queries(request):
    """Страница с демонстрацией ORM-запросов"""
    course_id = 1
    n = 1

    context = {
        'course_students': Student.objects.filter(enrollment__course_id=course_id),
        'course_id': course_id,
        'teachers_with_more_than_n_courses': Teacher.objects.annotate(
            course_count=Count('courses')
        ).filter(course_count__gt=n),
        'n': n,
        'students_without_courses': Student.objects.filter(enrollment__isnull=True),
        'teachers_without_profile': Teacher.objects.filter(info__isnull=True),
        'courses_with_student_count': Course.objects.annotate(student_count=Count('enrollment')),
        'teachers_with_course_count': Teacher.objects.annotate(course_count=Count('courses')),
        'title': 'ORM-запросы'
    }
    return render(request, 'schedule/orm_queries.html', context)
