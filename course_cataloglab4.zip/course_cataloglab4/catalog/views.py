from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Count
from schedule.models import Teacher, Course, Student, Enrollment
from .forms import StudentEnrollmentForm


def index(request):
    """Главная страница"""
    return render(request, 'catalog/index.html')


def courses_list(request):
    """Список всех курсов"""
    courses = Course.objects.all().select_related('teacher')
    context = {
        'courses': courses,
        'title': 'Список курсов'
    }
    return render(request, 'catalog/courses.html', context)


def course_detail(request, course_id):
    """Детальная страница курса"""
    course = get_object_or_404(Course, id=course_id)
    context = {
        'course': course,
        'title': course.title
    }
    return render(request, 'catalog/course_detail.html', context)


def authors_list(request):
    """Список всех преподавателей"""
    authors = Teacher.objects.all().prefetch_related('courses')
    context = {
        'authors': authors,
        'title': 'Список авторов'
    }
    return render(request, 'catalog/authors.html', context)


def author_detail(request, author_id):
    """Детальная страница преподавателя"""
    author = get_object_or_404(Teacher, id=author_id)
    context = {
        'author': author,
        'title': f'{author.first_name} {author.last_name}'
    }
    return render(request, 'catalog/author_details.html', context)


def info(request):
    """Страница информации"""
    context = {
        'title': 'Информация',
        'courses_count': Course.objects.count(),
        'authors_count': Teacher.objects.count(),
    }
    return render(request, 'catalog/info.html', context)


def not_found(request, exception=None):
    """Страница 404"""
    return render(request, 'catalog/not_found.html', {'title': 'Страница не найдена'}, status=404)


def enroll_course(request, course_id=None):
    """Запись на курс"""
    initial_data = {}
    if course_id:
        course = Course.objects.filter(id=course_id).first()
        if course:
            initial_data['course'] = course

    if request.method == 'POST':
        form = StudentEnrollmentForm(request.POST)
        if form.is_valid():
            try:
                student, enrollment = form.save()
                messages.success(request, f'Студент {student.first_name} {student.last_name} успешно записан на курс!')
                return redirect('enrollment_success', enrollment_id=enrollment.id)
            except Exception as e:
                messages.error(request, f'Ошибка при записи: {e}')
    else:
        form = StudentEnrollmentForm(initial=initial_data)

    context = {
        'form': form,
        'courses': Course.objects.all().select_related('teacher'),
        'title': 'Запись на курс'
    }
    return render(request, 'catalog/enroll.html', context)


def enrollment_success(request, enrollment_id):
    """Страница успешной записи"""
    enrollment = get_object_or_404(Enrollment, id=enrollment_id)
    context = {
        'enrollment': enrollment,
        'title': 'Запись оформлена'
    }
    return render(request, 'catalog/enrollment_success.html', context)


def orm_queries(request):
    """Страница с демонстрацией ORM-запросов"""
    course_id = 1
    n = 1

    context = {
        # 1. Все студенты курса с id=1
        'course_students': Student.objects.filter(enrollment__course_id=course_id),
        'course_id': course_id,
        # 2. Преподаватели с количеством курсов больше n
        'teachers_with_more_than_n_courses': Teacher.objects.annotate(
            course_count=Count('courses')
        ).filter(course_count__gt=n),
        'n': n,
        # 3. Студенты без курсов
        'students_without_courses': Student.objects.filter(enrollment__isnull=True),
        # 4. Преподаватели без профиля
        'teachers_without_profile': Teacher.objects.filter(info__isnull=True),
        # 5. Курсы с количеством студентов
        'courses_with_student_count': Course.objects.annotate(student_count=Count('enrollment')),
        # 6. Преподаватели с количеством курсов
        'teachers_with_course_count': Teacher.objects.annotate(course_count=Count('courses')),
        'title': 'ORM-запросы'
    }
    return render(request, 'catalog/orm_queries.html', context)
