from django.db import migrations, models
import django.core.validators


class Migration(migrations.Migration):

    dependencies = [
        ('schedule', '0001_initial'),
    ]

    operations = [

        migrations.AddField(
            model_name='teacher',
            name='salary',
            field=models.DecimalField(
                decimal_places=2, default=0, max_digits=10,
                validators=[django.core.validators.MinValueValidator(0)],
                verbose_name='Зарплата'
            ),
        ),
        migrations.AddField(
            model_name='teacher',
            name='years_of_experience',
            field=models.PositiveIntegerField(
                default=0,
                validators=[django.core.validators.MaxValueValidator(60)],
                verbose_name='Лет опыта'
            ),
        ),
        migrations.AddField(
            model_name='teacher',
            name='rating',
            field=models.DecimalField(
                decimal_places=1, default=5.0, max_digits=3,
                validators=[
                    django.core.validators.MinValueValidator(0.0),
                    django.core.validators.MaxValueValidator(10.0),
                ],
                verbose_name='Рейтинг'
            ),
        ),
        migrations.AddField(
            model_name='teacher',
            name='department',
            field=models.CharField(blank=True, default='', max_length=100, verbose_name='Отдел'),
        ),
        migrations.AddField(
            model_name='teacher',
            name='max_students',
            field=models.PositiveIntegerField(
                default=30,
                validators=[
                    django.core.validators.MinValueValidator(1),
                    django.core.validators.MaxValueValidator(500),
                ],
                verbose_name='Макс. студентов'
            ),
        ),

        migrations.AddField(
            model_name='teacherinfo',
            name='github_url',
            field=models.URLField(blank=True, null=True, verbose_name='GitHub'),
        ),
        migrations.AddField(
            model_name='teacherinfo',
            name='publications_count',
            field=models.PositiveIntegerField(default=0, verbose_name='Количество публикаций'),
        ),
        migrations.AddField(
            model_name='teacherinfo',
            name='languages',
            field=models.CharField(blank=True, default='Русский', max_length=200, verbose_name='Языки'),
        ),
        migrations.AddField(
            model_name='teacherinfo',
            name='awards',
            field=models.TextField(blank=True, default='', max_length=500, verbose_name='Награды'),
        ),
        migrations.AddField(
            model_name='teacherinfo',
            name='is_verified',
            field=models.BooleanField(default=False, verbose_name='Верифицирован'),
        ),

        # Course: 5 новых полей
        migrations.AddField(
            model_name='course',
            name='end_date',
            field=models.DateField(blank=True, null=True, verbose_name='Дата окончания'),
        ),
        migrations.AddField(
            model_name='course',
            name='level',
            field=models.CharField(
                choices=[('BEG', 'Начинающий'), ('INT', 'Средний'), ('ADV', 'Продвинутый')],
                default='BEG', max_length=3, verbose_name='Уровень'
            ),
        ),
        migrations.AddField(
            model_name='course',
            name='max_students',
            field=models.PositiveIntegerField(
                default=20,
                validators=[django.core.validators.MinValueValidator(1)],
                verbose_name='Макс. студентов'
            ),
        ),
        migrations.AddField(
            model_name='course',
            name='is_published',
            field=models.BooleanField(default=False, verbose_name='Опубликован'),
        ),
        migrations.AddField(
            model_name='course',
            name='discount',
            field=models.PositiveIntegerField(
                default=0,
                validators=[django.core.validators.MaxValueValidator(100)],
                verbose_name='Скидка (%)'
            ),
        ),

        migrations.AddField(
            model_name='student',
            name='city',
            field=models.CharField(blank=True, default='', max_length=100, verbose_name='Город'),
        ),
        migrations.AddField(
            model_name='student',
            name='education_level',
            field=models.CharField(blank=True, default='', max_length=50, verbose_name='Уровень образования'),
        ),
        migrations.AddField(
            model_name='student',
            name='is_employed',
            field=models.BooleanField(default=False, verbose_name='Трудоустроен'),
        ),
        migrations.AddField(
            model_name='student',
            name='gpa',
            field=models.DecimalField(
                blank=True, decimal_places=1, max_digits=3, null=True,
                validators=[
                    django.core.validators.MinValueValidator(0.0),
                    django.core.validators.MaxValueValidator(5.0),
                ],
                verbose_name='Средний балл'
            ),
        ),
        migrations.AddField(
            model_name='student',
            name='telegram',
            field=models.CharField(blank=True, default='', max_length=100, verbose_name='Telegram'),
        ),

        # Course: добавить validator на duration и price
        migrations.AlterField(
            model_name='course',
            name='duration',
            field=models.IntegerField(
                validators=[django.core.validators.MinValueValidator(1)],
                verbose_name='Длительность (часов)'
            ),
        ),
        migrations.AlterField(
            model_name='course',
            name='price',
            field=models.DecimalField(
                decimal_places=2, max_digits=10,
                validators=[django.core.validators.MinValueValidator(0)],
                verbose_name='Цена'
            ),
        ),
    ]
