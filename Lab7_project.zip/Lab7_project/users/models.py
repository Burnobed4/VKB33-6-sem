from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):
    """Кастомная модель пользователя, наследуемая от AbstractUser."""
    bio = models.TextField(blank=True, verbose_name='О себе')
    phone = models.CharField(max_length=20, blank=True, verbose_name='Номер телефона')
    avatar = models.ImageField(
        upload_to='avatars/',
        blank=True,
        null=True,
        verbose_name='Аватарка'
    )
    friends = models.ManyToManyField(
        'self',
        symmetrical=False,
        blank=True,
        related_name='friend_of',
        verbose_name='Друзья'
    )

    def __str__(self):
        return self.username

    def is_friend(self, user):
        """Проверяет, является ли user другом текущего пользователя."""
        return self.friends.filter(pk=user.pk).exists()

    def can_view_profile(self, viewer):
        """Может ли viewer смотреть профиль этого пользователя."""
        if viewer == self:
            return True
        if not viewer.is_authenticated:
            return False
        return viewer.is_friend(self)
