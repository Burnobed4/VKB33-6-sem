from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('list/', views.user_list, name='user_list'),
    path('edit/', views.profile_edit, name='profile_edit'),
    path('<str:username>/', views.profile, name='profile'),
    path('<str:username>/add/', views.add_friend, name='add_friend'),
    path('<str:username>/remove/', views.remove_friend, name='remove_friend'),
]
