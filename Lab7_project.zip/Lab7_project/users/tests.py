import pytest
from django.urls import reverse
from users.models import CustomUser


# ---------------------------------------------------------------------------
# Фикстуры
# ---------------------------------------------------------------------------

@pytest.fixture
def user(db):
    """Обычный пользователь."""
    return CustomUser.objects.create_user(
        username='alice',
        email='alice@example.com',
        password='StrongPass123',
        phone='+79001234567',
    )


@pytest.fixture
def other_user(db):
    """Второй пользователь."""
    return CustomUser.objects.create_user(
        username='bob',
        email='bob@example.com',
        password='StrongPass123',
    )


@pytest.fixture
def third_user(db):
    """Третий пользователь — незнакомец."""
    return CustomUser.objects.create_user(
        username='charlie',
        email='charlie@example.com',
        password='StrongPass123',
    )


@pytest.fixture
def auth_client(client, user):
    """Клиент с залогиненным пользователем alice."""
    client.login(username='alice', password='StrongPass123')
    return client


@pytest.fixture
def friends_pair(db, user, other_user):
    """Alice добавила Bob в друзья."""
    user.friends.add(other_user)
    return user, other_user


# ---------------------------------------------------------------------------
# Тесты регистрации
# ---------------------------------------------------------------------------

class TestRegistration:

    @pytest.mark.parametrize('username,email,password1,password2,expected_status', [
        ('newuser',  'new@example.com',  'StrongPass999', 'StrongPass999', 302),
        ('newuser2', 'new2@example.com', 'StrongPass999', 'WrongPass000',  200),
        ('',         'new3@example.com', 'StrongPass999', 'StrongPass999', 200),
        ('newuser4', 'not-an-email',     'StrongPass999', 'StrongPass999', 200),
        ('newuser5', 'new5@example.com', '12345678',      '12345678',      200),
    ])
    def test_register_form_validation(
        self, client, db, username, email, password1, password2, expected_status
    ):
        response = client.post(reverse('register'), {
            'username': username,
            'email': email,
            'password1': password1,
            'password2': password2,
        })
        assert response.status_code == expected_status

    def test_register_creates_user(self, client, db):
        """После успешной регистрации пользователь создаётся в БД."""
        client.post(reverse('register'), {
            'username': 'newuser',
            'email': 'new@example.com',
            'password1': 'StrongPass999',
            'password2': 'StrongPass999',
        })
        assert CustomUser.objects.filter(username='newuser').exists()

    def test_register_auto_login(self, client, db):
        """После регистрации пользователь автоматически залогинен."""
        client.post(reverse('register'), {
            'username': 'newuser',
            'email': 'new@example.com',
            'password1': 'StrongPass999',
            'password2': 'StrongPass999',
        })
        response = client.get(reverse('home'))
        assert response.status_code == 200
        assert b'newuser' in response.content

    def test_register_redirect_on_success(self, client, db):
        """После регистрации редирект на главную."""
        response = client.post(reverse('register'), {
            'username': 'newuser',
            'email': 'new@example.com',
            'password1': 'StrongPass999',
            'password2': 'StrongPass999',
        })
        assert response.status_code == 302
        assert response['Location'] == reverse('home')

    def test_register_duplicate_username(self, client, user):
        """Регистрация с уже существующим именем — ошибка."""
        response = client.post(reverse('register'), {
            'username': 'alice',
            'email': 'other@example.com',
            'password1': 'StrongPass999',
            'password2': 'StrongPass999',
        })
        assert response.status_code == 200
        assert CustomUser.objects.filter(username='alice').count() == 1

    def test_register_page_get(self, client, db):
        """GET на страницу регистрации возвращает форму."""
        response = client.get(reverse('register'))
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Тесты входа и выхода
# ---------------------------------------------------------------------------

class TestLoginLogout:

    @pytest.mark.parametrize('username,password,should_redirect', [
        ('alice', 'StrongPass123', True),
        ('alice', 'wrongpassword', False),
        ('nonexistent', 'StrongPass123', False),
        ('', '', False),
    ])
    def test_login(self, client, user, username, password, should_redirect):
        response = client.post(reverse('login'), {
            'username': username,
            'password': password,
        })
        if should_redirect:
            assert response.status_code == 302
        else:
            assert response.status_code == 200

    def test_login_page_accessible_to_anonymous(self, client, db):
        response = client.get(reverse('login'))
        assert response.status_code == 200

    def test_logout_redirects(self, auth_client):
        """После выхода — редирект на главную."""
        response = auth_client.post(reverse('logout'))
        assert response.status_code == 302
        assert response['Location'] == '/'

    def test_logout_clears_session(self, auth_client):
        """После выхода пользователь не залогинен — защищённый URL недоступен."""
        auth_client.post(reverse('logout'))
        response = auth_client.get(reverse('user_list'))
        assert response.status_code == 302


# ---------------------------------------------------------------------------
# Тесты проверки доступа (авторизация)
# ---------------------------------------------------------------------------

class TestAccessControl:

    @pytest.mark.parametrize('url_name', ['user_list', 'profile_edit'])
    def test_anonymous_redirected_to_login(self, client, db, url_name):
        """Анонимный пользователь редиректится на страницу логина."""
        response = client.get(reverse(url_name))
        assert response.status_code == 302
        assert '/auth/login/' in response['Location']

    def test_anonymous_cannot_access_profile(self, client, user):
        """Анонимный пользователь не может открыть профиль."""
        response = client.get(reverse('profile', kwargs={'username': user.username}))
        assert response.status_code == 302
        assert '/auth/login/' in response['Location']

    def test_authenticated_can_access_user_list(self, auth_client):
        response = auth_client.get(reverse('user_list'))
        assert response.status_code == 200

    def test_authenticated_can_access_own_profile(self, auth_client, user):
        response = auth_client.get(reverse('profile', kwargs={'username': user.username}))
        assert response.status_code == 200

    def test_authenticated_can_edit_own_profile(self, auth_client):
        response = auth_client.get(reverse('profile_edit'))
        assert response.status_code == 200

    def test_home_accessible_to_anonymous(self, client, db):
        response = client.get(reverse('home'))
        assert response.status_code == 200


# ---------------------------------------------------------------------------
# Тесты permissions
# ---------------------------------------------------------------------------

class TestPermissions:

    def test_stranger_cannot_view_profile(self, auth_client, third_user):
        """Alice не может смотреть профиль незнакомца Charlie."""
        response = auth_client.get(
            reverse('profile', kwargs={'username': third_user.username})
        )
        assert response.status_code == 302
        assert response['Location'] == reverse('user_list')

    def test_friend_can_view_profile(self, client, friends_pair):
        """Alice может смотреть профиль Bob, т.к. он у неё в друзьях."""
        alice, bob = friends_pair
        client.login(username='alice', password='StrongPass123')
        response = client.get(reverse('profile', kwargs={'username': bob.username}))
        assert response.status_code == 200

    def test_can_view_own_profile(self, auth_client, user):
        """Пользователь всегда может смотреть свой профиль."""
        response = auth_client.get(reverse('profile', kwargs={'username': user.username}))
        assert response.status_code == 200

    def test_model_can_view_profile_own(self, user):
        """Метод модели: пользователь видит свой профиль."""
        assert user.can_view_profile(user) is True

    def test_model_can_view_profile_friend(self, user, other_user):
        """Метод модели: друг видит профиль."""
        user.friends.add(other_user)
        assert other_user.can_view_profile(user) is True

    def test_model_cannot_view_profile_stranger(self, user, third_user):
        """Метод модели: незнакомец не видит профиль."""
        assert user.can_view_profile(third_user) is False

    def test_cannot_add_self_as_friend(self, auth_client, user):
        """Нельзя добавить себя в друзья."""
        auth_client.post(reverse('add_friend', kwargs={'username': user.username}))
        assert not user.friends.filter(pk=user.pk).exists()

    @pytest.mark.parametrize('url_name', ['add_friend', 'remove_friend'])
    def test_friend_actions_require_auth(self, client, other_user, url_name):
        """Действия с друзьями требуют авторизации."""
        response = client.post(
            reverse(url_name, kwargs={'username': other_user.username})
        )
        assert response.status_code == 302
        assert '/auth/login/' in response['Location']


# ---------------------------------------------------------------------------
# Тесты редиректов (assertRedirects)
# ---------------------------------------------------------------------------

class TestRedirects:

    def test_register_success_redirects_to_home(self, client, db):
        response = client.post(reverse('register'), {
            'username': 'newuser',
            'email': 'new@example.com',
            'password1': 'StrongPass999',
            'password2': 'StrongPass999',
        })
        assert response.status_code == 302
        assert response['Location'] == reverse('home')

    def test_login_success_redirects_to_home(self, client, user):
        response = client.post(reverse('login'), {
            'username': 'alice',
            'password': 'StrongPass123',
        })
        assert response.status_code == 302
        assert response['Location'] == reverse('home')

    def test_logout_redirects_to_home(self, auth_client):
        response = auth_client.post(reverse('logout'))
        assert response.status_code == 302
        assert response['Location'] == '/'

    def test_profile_edit_save_redirects_to_profile(self, auth_client, user):
        response = auth_client.post(reverse('profile_edit'), {
            'first_name': 'Alice',
            'last_name': 'Smith',
            'email': 'alice@example.com',
            'phone': '+79001234567',
            'bio': 'Hello',
        })
        assert response.status_code == 302
        assert response['Location'] == reverse('profile', kwargs={'username': user.username})

    def test_add_friend_redirects_to_user_list(self, auth_client, other_user):
        response = auth_client.post(
            reverse('add_friend', kwargs={'username': other_user.username})
        )
        assert response.status_code == 302
        assert response['Location'] == reverse('user_list')

    def test_remove_friend_redirects_to_profile(self, auth_client, user, other_user):
        user.friends.add(other_user)
        response = auth_client.post(
            reverse('remove_friend', kwargs={'username': other_user.username})
        )
        assert response.status_code == 302
        assert response['Location'] == reverse('profile', kwargs={'username': other_user.username})

    def test_stranger_profile_redirects_to_user_list(self, auth_client, third_user):
        response = auth_client.get(
            reverse('profile', kwargs={'username': third_user.username})
        )
        assert response.status_code == 302
        assert response['Location'] == reverse('user_list')

    def test_anonymous_user_list_redirects_to_login(self, client, db):
        response = client.get(reverse('user_list'))
        assert response.status_code == 302
        assert response['Location'] == '/auth/login/?next=/users/list/'


# ---------------------------------------------------------------------------
# Тесты ошибок
# ---------------------------------------------------------------------------

class TestErrors:

    def test_profile_404_for_nonexistent_user(self, auth_client):
        """Профиль несуществующего пользователя — 404."""
        response = auth_client.get(
            reverse('profile', kwargs={'username': 'doesnotexist'})
        )
        assert response.status_code == 404

    def test_add_friend_404_for_nonexistent_user(self, auth_client):
        response = auth_client.post(
            reverse('add_friend', kwargs={'username': 'doesnotexist'})
        )
        assert response.status_code == 404

    def test_remove_friend_404_for_nonexistent_user(self, auth_client):
        response = auth_client.post(
            reverse('remove_friend', kwargs={'username': 'doesnotexist'})
        )
        assert response.status_code == 404

    @pytest.mark.parametrize('field,value,should_fail', [
        ('username', '',             True),
        ('email',    'not-an-email', True),
        ('password1','123',          True),
        ('username', 'validuser',    False),
    ])
    def test_register_field_errors(self, client, db, field, value, should_fail):
        """Параметризованная проверка ошибок валидации формы регистрации."""
        data = {
            'username': 'testuser',
            'email': 'test@example.com',
            'password1': 'StrongPass999',
            'password2': 'StrongPass999',
        }
        data[field] = value
        if field == 'password1':
            data['password2'] = value
        response = client.post(reverse('register'), data)
        if should_fail:
            assert response.status_code == 200
        else:
            assert response.status_code == 302

    def test_login_wrong_password_returns_form(self, client, user):
        """Неверный пароль — форма возвращается с ошибкой."""
        response = client.post(reverse('login'), {
            'username': 'alice',
            'password': 'wrongpassword',
        })
        assert response.status_code == 200
        assert response.context['form'].errors
