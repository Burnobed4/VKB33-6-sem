from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('courses/', views.courses_list, name='courses_list'),
    path('courses/<int:course_id>/', views.course_detail, name='course_detail'),
    path('authors/', views.authors_list, name='authors_list'),
    path('authors/<int:author_id>/', views.author_detail, name='author_detail'),
    path('info/', views.info, name='info'),
    path('enroll/', views.enroll_course, name='enroll'),
    path('enroll/<int:course_id>/', views.enroll_course, name='enroll_course'),
    path('enroll/success/<int:enrollment_id>/', views.enrollment_success, name='enrollment_success'),
    path('orm-queries/', views.orm_queries, name='orm_queries'),
]