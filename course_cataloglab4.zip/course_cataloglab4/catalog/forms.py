import re
from django import forms
from django.core.exceptions import ValidationError
from schedule.models import Student, Course, Enrollment


class StudentEnrollmentForm(forms.ModelForm):
    course = forms.ModelChoiceField(
        queryset=Course.objects.all(),
        label='Выберите курс',
        widget=forms.Select(attrs={'class': 'form-control'})
    )

    class Meta:
        model = Student
        fields = ['first_name', 'last_name', 'email', 'phone', 'birth_date',
                  'city', 'education_level', 'is_employed', 'telegram']
        widgets = {
            'first_name':      forms.TextInput(attrs={'placeholder': 'Введите имя'}),
            'last_name':       forms.TextInput(attrs={'placeholder': 'Введите фамилию'}),
            'email':           forms.EmailInput(attrs={'placeholder': 'Введите email'}),
            'phone':           forms.TextInput(attrs={'placeholder': '+7 (999) 123-45-67'}),
            'birth_date':      forms.DateInput(attrs={'type': 'date'}),
            'city':            forms.TextInput(attrs={'placeholder': 'Москва'}),
            'education_level': forms.TextInput(attrs={'placeholder': 'Высшее / Среднее и т.д.'}),
            'telegram':        forms.TextInput(attrs={'placeholder': '@username'}),
        }
        labels = {
            'first_name':      'Имя',
            'last_name':       'Фамилия',
            'email':           'Email',
            'phone':           'Телефон',
            'birth_date':      'Дата рождения',
            'city':            'Город',
            'education_level': 'Уровень образования',
            'is_employed':     'Трудоустроен',
            'telegram':        'Telegram',
        }
        help_texts = {
            'phone':    'Необязательно',
            'city':     'Необязательно',
            'telegram': 'Необязательно',
        }

    def clean_first_name(self):
        value = self.cleaned_data.get('first_name', '').strip()
        if any(c.isdigit() for c in value):
            raise ValidationError('Имя не должно содержать цифры.')
        return value.capitalize()

    def clean_last_name(self):
        value = self.cleaned_data.get('last_name', '').strip()
        if any(c.isdigit() for c in value):
            raise ValidationError('Фамилия не должна содержать цифры.')
        return value.capitalize()

    def clean_email(self):
        return self.cleaned_data.get('email', '').strip().lower()

    def clean_phone(self):
        value = self.cleaned_data.get('phone', '')
        if value and not re.match(r'^\+?[\d\s\-\(\)]{7,20}$', value):
            raise ValidationError('Неверный формат телефона.')
        return value

    def clean_telegram(self):
        value = self.cleaned_data.get('telegram', '').strip()
        if value and not value.startswith('@'):
            value = '@' + value
        return value

    def clean(self):
        cleaned_data = super().clean()
        city = cleaned_data.get('city', '')
        is_employed = cleaned_data.get('is_employed')
        if is_employed and not city:
            raise ValidationError('Укажите город, если вы трудоустроены.')
        return cleaned_data

    def save(self, commit=True):
        course = self.cleaned_data.pop('course')
        student, created = Student.objects.get_or_create(
            email=self.cleaned_data['email'],
            defaults={k: v for k, v in self.cleaned_data.items()}
        )
        if not created:
            for field, value in self.cleaned_data.items():
                setattr(student, field, value)
            student.save()

        enrollment, _ = Enrollment.objects.get_or_create(
            student=student,
            course=course,
            defaults={'status': 'ENROLLED'}
        )
        return student, enrollment
