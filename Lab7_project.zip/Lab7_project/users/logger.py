import logging
import logging.handlers
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / 'logs'
LOG_DIR.mkdir(exist_ok=True)

# Форматтер с максимально информативным форматом
formatter = logging.Formatter(
    fmt='%(asctime)s | %(levelname)-8s | %(name)s | %(module)s:%(lineno)d | %(funcName)s | %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
)

# Хэндлер 1: консоль
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_handler.setFormatter(formatter)

# Хэндлер 2: файл с ротацией по размеру (5 МБ, хранить 5 файлов)
rotating_handler = logging.handlers.RotatingFileHandler(
    filename=LOG_DIR / 'app.log',
    maxBytes=5 * 1024 * 1024,
    backupCount=5,
    encoding='utf-8',
)
rotating_handler.setLevel(logging.DEBUG)
rotating_handler.setFormatter(formatter)

# Хэндлер 3: файл с ротацией по времени (каждый день, хранить 7 дней)
timed_handler = logging.handlers.TimedRotatingFileHandler(
    filename=LOG_DIR / 'app_daily.log',
    when='midnight',
    interval=1,
    backupCount=7,
    encoding='utf-8',
)
timed_handler.suffix = '%Y-%m-%d'
timed_handler.setLevel(logging.DEBUG)
timed_handler.setFormatter(formatter)


def get_logger(name: str) -> logging.Logger:
    """Возвращает настроенный логгер для модуля."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)
        logger.addHandler(console_handler)
        logger.addHandler(rotating_handler)
        logger.addHandler(timed_handler)
        logger.propagate = False
    return logger
