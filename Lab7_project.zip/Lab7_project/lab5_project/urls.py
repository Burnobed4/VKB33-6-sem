from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render
from django.conf import settings
from django.conf.urls.static import static
from users.views import custom_login


def home(request):
    return render(request, 'home.html')


def access_denied(request, exception=None):
    return render(request, '403.html', status=403)


urlpatterns = [
    path('admin/', admin.site.urls),
    # Подключаем стандартные auth URLs, но логин переопределяем своим view
    path('auth/login/', custom_login, name='login'),
    path('auth/', include('django.contrib.auth.urls')),
    path('users/', include('users.urls')),
    path('', home, name='home'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

handler403 = 'lab5_project.urls.access_denied'
