# Модели каталога намеренно отсутствуют.
# Все модели (Teacher, TeacherInfo, Course, Student, Enrollment)
# находятся в приложении schedule.
