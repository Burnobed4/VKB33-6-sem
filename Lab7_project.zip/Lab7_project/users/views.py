import logging.handlers

from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404

from .forms import RegisterForm, ProfileEditForm
from .logger import get_logger
from .models import CustomUser

# Логгер для данного модуля
logger = get_logger(__name__)


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            logger.info("User %s registered and logged in", user.username)
            return redirect('home')
        else:
            # Логируем каждую ошибку валидации отдельно
            for field, errors in form.errors.items():
                for error in errors:
                    logger.warning(
                        "Registration validation error — field '%s': %s",
                        field, error
                    )
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


def custom_login(request):
    """Обёртка над логином для логирования успеха и неудачи."""
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            logger.info("User %s logged in successfully", username)
            return redirect('home')
        else:
            logger.warning("Failed login attempt for username '%s'", username)
    # Для GET или неудачного POST рендерим стандартную форму логина
    from django.contrib.auth.views import LoginView
    return LoginView.as_view()(request)


@login_required
def user_list(request):
    """Список всех пользователей — только для аутентифицированных."""
    my_friends = set(request.user.friends.values_list('pk', flat=True))
    users = CustomUser.objects.exclude(pk=request.user.pk)
    users_with_flag = [
        {'user': u, 'is_friend': u.pk in my_friends}
        for u in users
    ]
    logger.info("User %s viewed user list", request.user.username)
    return render(request, 'users/user_list.html', {'users_with_flag': users_with_flag})


@login_required
def profile(request, username):
    """Страница профиля пользователя."""
    profile_user = get_object_or_404(CustomUser, username=username)

    if not profile_user.can_view_profile(request.user):
        logger.warning(
            "User %s tried to view profile of %s without permission",
            request.user.username, username
        )
        messages.error(request, 'Вы не можете просматривать эту страницу. Сначала добавьте пользователя в друзья.')
        return redirect('user_list')

    is_own = (request.user == profile_user)
    is_friend = request.user.is_friend(profile_user)

    my_friends = set(request.user.friends.values_list('pk', flat=True))
    friends_list = [
        {'user': f, 'can_view': (f.pk in my_friends or is_own)}
        for f in profile_user.friends.all()
    ]

    return render(request, 'users/profile.html', {
        'profile_user': profile_user,
        'is_own': is_own,
        'is_friend': is_friend,
        'friends_list': friends_list,
    })


@login_required
def profile_edit(request):
    """Редактирование своего профиля."""
    if request.method == 'POST':
        form = ProfileEditForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            # Проверяем что загруженный файл — изображение
            avatar_file = request.FILES.get('avatar')
            if avatar_file:
                try:
                    from PIL import Image
                    img = Image.open(avatar_file)
                    img.verify()
                    avatar_file.seek(0)  # сбрасываем позицию после verify()
                    logger.info(
                        "User %s uploaded avatar: %s",
                        request.user.username, avatar_file.name
                    )
                except Exception as e:
                    logger.error(
                        "User %s tried to upload non-image file '%s' as avatar",
                        request.user.username, avatar_file.name,
                        exc_info=True
                    )
                    messages.error(request, 'Загруженный файл не является изображением.')
                    return render(request, 'users/profile_edit.html', {'form': form})

            form.save()
            logger.info("User %s updated their profile", request.user.username)
            messages.success(request, 'Профиль обновлён.')
            return redirect('profile', username=request.user.username)
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    logger.warning(
                        "Profile edit validation error for user %s — field '%s': %s",
                        request.user.username, field, error
                    )
    else:
        form = ProfileEditForm(instance=request.user)
    return render(request, 'users/profile_edit.html', {'form': form})


@login_required
def add_friend(request, username):
    """Добавить пользователя в друзья."""
    target = get_object_or_404(CustomUser, username=username)
    if target == request.user:
        logger.warning("User %s tried to add themselves as a friend", request.user.username)
        messages.error(request, 'Нельзя добавить себя в друзья.')
    else:
        request.user.friends.add(target)
        logger.info("User %s added %s as a friend", request.user.username, target.username)
        messages.success(request, f'Пользователь {target.username} добавлен в друзья.')
    return redirect('user_list')


@login_required
def remove_friend(request, username):
    """Удалить пользователя из друзей."""
    target = get_object_or_404(CustomUser, username=username)
    request.user.friends.remove(target)
    logger.info("User %s removed %s from friends", request.user.username, target.username)
    messages.success(request, f'Пользователь {target.username} удалён из друзей.')
    return redirect('profile', username=username)
